create view applicable_roles(grantee, role_name, is_grantable) as
SELECT a.rolname::information_schema.sql_identifier AS grantee,
       b.rolname::information_schema.sql_identifier AS role_name,
       CASE
           WHEN m.admin_option THEN 'YES'::text
           ELSE 'NO'::text
           END::information_schema.yes_or_no        AS is_grantable
FROM pg_auth_members m
         JOIN pg_authid a ON m.member = a.oid
         JOIN pg_authid b ON m.roleid = b.oid
WHERE pg_has_role(a.oid, 'USAGE'::text);

alter table applicable_roles
    owner to postgres;

grant select on applicable_roles to public;

